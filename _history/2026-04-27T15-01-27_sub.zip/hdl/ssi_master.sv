`default_nettype none
// ===== SSI Master with Differential I/O =====
module ssi_master #(
    parameter CLK_FREQ_MHZ = 100,
    parameter POSITION_BITS = 19,
    parameter STATUS_BITS = 10,
    parameter TOTAL_BITS = 30
)(
    input wire clk,
    input wire rst,
    input wire trigger,
    input wire [9:0] ssi_clk_freq_khz,      // Configurable SSI clock frequency
    
    // Differential SSI interface
    output wire ssi_clk_p,
    output wire ssi_clk_n,
    input wire ssi_data_p,
    input wire ssi_data_n,
    
    // Parallel outputs
    output logic [POSITION_BITS-1:0] position,
    output logic [STATUS_BITS-1:0] status,
    output logic data_valid,
    output logic busy,
    output logic error_flag,
    output logic warning_flag
);

    logic ssi_clk_internal;
    logic ssi_data_internal;

    // assign ssi_clk_p = ssi_clk_internal; 
    // assign ssi_clk_n = !ssi_clk_p;
    // assign ssi_data_internal = ssi_data_p;

    
    // ===== Differential I/O Buffers =====
    // OBUFDS: Convert single-ended clock to differential
    OBUFDS #(     
        .SLEW("FAST")               // Slow slew rate for cleaner edges
    ) obufds_clk_inst (
        .I(ssi_clk_internal),       // Single-ended input
        .O(ssi_clk_p),              // Positive output
        .OB(ssi_clk_n)              // Negative output (inverted)
    );
    
    // IBUFDS: Convert differential data to single-ended
    IBUFDS #(
        // .DIFF_TERM("TRUE"),         // Enable 100Ω differential termination
        // .IOSTANDARD("LVCMOS33")
    ) ibufds_data_inst (
        .I(ssi_data_p),             // Positive input
        .IB(ssi_data_n),            // Negative input
        .O(ssi_data_internal)       // Single-ended output
    );
    
    // SSI Core 
    logic [$clog2(25*CLK_FREQ_MHZ)-1:0] timer;
    logic [$clog2(1000)-1:0] clk_counter;
    logic [$clog2(TOTAL_BITS+1)-1:0] bit_counter;
    logic [TOTAL_BITS-1:0] shift_reg;
    
    logic [15:0] ssi_clk_half_period;
    
    // Calculate SSI clock half period dynamically
    always_comb begin
        ssi_clk_half_period = (CLK_FREQ_MHZ * 1000) / (2 * ssi_clk_freq_khz); //division baddd
    end
    
    typedef enum logic [3:0] {
        IDLE,
        WAIT_INITIAL,
        CLOCK_LOW,
        CLOCK_HIGH,
        CAPTURE_DATA,
        WAIT_MONOFLOP,
        WAIT_PAUSE,
        DONE
    } state_t;
    
    state_t state;
    
    // Trigger edge detection
    logic [2:0] trigger_pipe;
    logic trigger_edge;
    
    always_ff @(posedge clk) begin
        if (rst) begin
            trigger_pipe <= 3'b000;
        end else begin
            trigger_pipe <= {trigger_pipe[1:0], trigger};
        end
    end
    
    assign trigger_edge = trigger_pipe[1] && !trigger_pipe[2];
    
    // Main state machine
    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            ssi_clk_internal <= 1'b1;
            shift_reg <= 0;
            bit_counter <= 0;
            clk_counter <= 0;
            timer <= 0;
            position <= 0;
            status <= 0;
            data_valid <= 1'b0;
            busy <= 1'b0;
            error_flag <= 1'b0;
            warning_flag <= 1'b0;    
        end else begin
            data_valid <= 1'b0;  // Default: pulse
            
            case (state)
                IDLE: begin
                    ssi_clk_internal <= 1'b1;
                    bit_counter <= 0;
                    clk_counter <= 0;
                    timer <= 0;
                    busy <= 1'b0;
                    
                    if (trigger_edge) begin
                        busy <= 1'b1;
                        shift_reg <= 0;
                        state <= WAIT_INITIAL;
                    end
                end
                
                WAIT_INITIAL: begin
                    // Wait 2us before first clock
                    ssi_clk_internal <= 1'b0;
                    timer <= timer + 1;
                    if (timer >= (2 * CLK_FREQ_MHZ) - 1) begin
                        timer <= '0;
                        state <= CLOCK_LOW;
                    end
                end
                
                CLOCK_LOW: begin
                    if (clk_counter == 0) begin
                        ssi_clk_internal <= 1'b0;
                    end
                    clk_counter <= clk_counter + 1;
                    
                    if (clk_counter >= ssi_clk_half_period - 1) begin
                        clk_counter <= 0;
                        state <= CLOCK_HIGH;
                    end
                end
                
                CLOCK_HIGH: begin
                    if (clk_counter == 0) begin
                        ssi_clk_internal <= 1'b1;
                    end
                    clk_counter <= clk_counter + 1;
                    
                    if (clk_counter >= ssi_clk_half_period - 1) begin
                        clk_counter <= '0;
                        state <= CAPTURE_DATA;
                    end
                end
                
                CAPTURE_DATA: begin
                    // Sample data after rising edge (account for tRESP delay)
                    shift_reg <= {shift_reg[TOTAL_BITS-2:0], ssi_data_internal};
                    bit_counter <= bit_counter + 1;
                    
                    if (bit_counter >= TOTAL_BITS - 1) begin
                        state <= WAIT_MONOFLOP;
                        timer <= '0;
                    end else begin
                        state <= CLOCK_LOW;
                    end
                end
                
                WAIT_MONOFLOP: begin
                    ssi_clk_internal <= 1'b1;
                    timer <= timer + 1;
                    
                    // Wait 22µs for monoflop timeout
                    if (timer >= (22 * CLK_FREQ_MHZ) - 1) begin
                        timer <= '0;
                        state <= WAIT_PAUSE;
                        
                        // Parse received data
                        // Format: [start bit][19 position][10 status]
                        position <= shift_reg[TOTAL_BITS-2 -: POSITION_BITS];
                        status <= shift_reg[STATUS_BITS-1:0];
                        error_flag <= shift_reg[9];
                        warning_flag <= shift_reg[8];
                    end
                end
                
                WAIT_PAUSE: begin
                    ssi_clk_internal <= 1'b1;
                    timer <= timer + 1;
                    
                    // Wait 25µs pause (tM + 2µs + margin)
                    if (timer >= (25 * CLK_FREQ_MHZ) - 1) begin
                        state <= DONE;
                    end
                end
                
                DONE: begin
                    data_valid <= 1'b1;
                    busy <= 1'b0;
                    state <= IDLE;
                end
                
                default: state <= IDLE;
            endcase
        end
    end

endmodule

`default_nettype wire