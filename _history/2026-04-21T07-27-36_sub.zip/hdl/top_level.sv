`default_nettype none

module top_level(
    input wire clk_100mhz,          // 100 MHz clock from Urbana board
    input wire [15:0] sw,           // Switches
    input wire [3:0] btn,           // Buttons
    output logic [15:0] led,        // LEDs
    output logic [2:0] rgb0,        // RGB LED 0
    output logic [2:0] rgb1,        // RGB LED 1
    output logic [3:0] ss0_an,      // Seven segment anodes
    output logic [3:0] ss1_an,
    output logic [6:0] ss0_c,       // Seven segment cathodes
    output logic [6:0] ss1_c,
    
    // PMOD JA pins for SSI (differential pairs)
    // Use PMOD connector with differential capability
    output wire pmod_ja_p1,              // SSI Clock positive
    output wire pmod_ja_n1,              // SSI Clock negative
    input wire pmod_ja_p2,               // SSI Data positive
    input wire pmod_ja_n2,                // SSI Data negative

    input wire              uart_rxd, // UART computer->FPGA
    output logic            uart_txd, // UART FPGA->computer

    //debug ports:
    output logic debug_pmod_ja_p1,        //change name of pmodb[0] in default xdc
    output logic debug_pmod_ja_n1,        //change name of pmodb[1] in default xdc
    output logic debug_pmod_ja_p2,        //change name of pmodb[2] in default xdc
    output logic debug_pmod_ja_n2,          //change name of pmodb[3] in default xdc
    output logic debug_uart_rxd,    //change name of pmodb[4] in default xdc
    output logic debug_uart_txd     //change name of pmodb[5] in default xdc
);

    // ===== Reset and Trigger Logic =====
    logic rst;
    logic trigger;
    logic [23:0] auto_trigger_counter;
    logic auto_trigger;
    
    assign rst = btn[0];
    assign debug_pmod_ja_p1       = pmod_ja_p1;
    assign debug_pmod_ja_n1       = pmod_ja_n1;
    assign debug_pmod_ja_p2       = pmod_ja_p2;
    assign debug_pmod_ja_n2         = pmod_ja_n2;
    assign debug_uart_rxd   = uart_rxd;
    assign debug_uart_txd   = uart_txd;
    
    // Auto-trigger for continuous reading (adjustable rate)
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            auto_trigger_counter <= '0;
            auto_trigger <= 1'b0;
        end else begin
            // Trigger every 100ms (well above tB = 70µs requirement)
            if (auto_trigger_counter >= 24'd10_000_000) begin
                auto_trigger_counter <= '0;
                auto_trigger <= 1'b1;
            end else begin
                auto_trigger_counter <= auto_trigger_counter + 1;
                auto_trigger <= 1'b0;
            end
        end
    end
    
    // Manual trigger with debouncing
    logic [19:0] btn_debounce;
    logic btn_trigger;
    
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            btn_debounce <= '0;
            btn_trigger <= 1'b0;
        end else begin
            if (btn[1]) begin
                if (btn_debounce < 20'd100_000) begin
                    btn_debounce <= btn_debounce + 1;
                    btn_trigger <= 1'b0;
                end else begin
                    btn_trigger <= 1'b1;
                end
            end else begin
                btn_debounce <= '0;
                btn_trigger <= 1'b0;
            end
        end
    end
    
    // Select trigger source: SW[15] = 1 for auto, 0 for manual
    assign trigger = sw[15] ? auto_trigger : btn_trigger;
    
    // ===== SSI Master Instance =====
    logic [18:0] encoder_position;
    logic [9:0] encoder_status;
    logic data_valid;
    logic busy;
    logic error_flag, warning_flag;
    
    // Adjust clock frequency based on cable length
    // 500 kHz (short cable <5m)
    logic [9:0] ssi_clk_freq;
    assign ssi_clk_freq = 10'd500;
    
    ssi_master #(
        .CLK_FREQ_MHZ(100),
        .POSITION_BITS(19),
        .STATUS_BITS(10),
        .TOTAL_BITS(30)
    ) ssi_inst (
        .clk(clk_100mhz),
        .rst(rst),
        .trigger(trigger),
        .ssi_clk_freq_khz(ssi_clk_freq),
        
        // Differential I/O 
        .ssi_clk_p(pmod_ja_p1),
        .ssi_clk_n(pmod_ja_n1),
        .ssi_data_p(pmod_ja_p2),
        .ssi_data_n(pmod_ja_n2),
        
        // Parallel outputs
        .position(encoder_position),
        .status(encoder_status),
        .data_valid(data_valid),
        .busy(busy),
        .error_flag(error_flag),
        .warning_flag(warning_flag)
    );
    
    // ===== LED Display =====
    assign led[15] = sw[15];            // Auto-trigger mode indicator
    assign led[14] = busy;              // Busy indicator
    assign led[13] = error_flag;        // Error flag
    assign led[12] = warning_flag;      // Warning flag
    assign led[11] = data_valid;        // Data valid pulse
    assign led[10:0] = encoder_position[18:8];  // Upper 11 bits of position
    
    // ===== RGB LED Status =====
    // RGB0: Error/Warning/OK status
    assign rgb0[0] = error_flag;                        // Red = Error
    assign rgb0[1] = warning_flag && !error_flag;       // Green = Warning
    assign rgb0[2] = !error_flag && !warning_flag;      // Blue = OK
    
    // RGB1: Busy/Activity indicator (blink on data valid)
    logic [23:0] blink_counter;
    logic blink;
    
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            blink_counter <= '0;
            blink <= 1'b0;
        end else begin
            if (data_valid) begin
                blink_counter <= 24'd5_000_000;  // 50ms blink
            end else if (blink_counter > 0) begin
                blink_counter <= blink_counter - 1;
            end
            
            blink <= (blink_counter > 0);
        end
    end
    
    assign rgb1[0] = 1'b0;
    assign rgb1[1] = blink;  // Green blink on new data
    assign rgb1[2] = 1'b0;

    // function automatic [7:0] hex_to_ascii(input logic [3:0] nib);
    //     begin
    //         case (nib)
    //             4'h0: hex_to_ascii = "0";
    //             4'h1: hex_to_ascii = "1";
    //             4'h2: hex_to_ascii = "2";
    //             4'h3: hex_to_ascii = "3";
    //             4'h4: hex_to_ascii = "4";
    //             4'h5: hex_to_ascii = "5";
    //             4'h6: hex_to_ascii = "6";
    //             4'h7: hex_to_ascii = "7";
    //             4'h8: hex_to_ascii = "8";
    //             4'h9: hex_to_ascii = "9";
    //             4'hA: hex_to_ascii = "A";
    //             4'hB: hex_to_ascii = "B";
    //             4'hC: hex_to_ascii = "C";
    //             4'hD: hex_to_ascii = "D";
    //             4'hE: hex_to_ascii = "E";
    //             4'hF: hex_to_ascii = "F";
    //         endcase
    //     end
    // endfunction

    logic [18:0] encoder_position_latched;
    logic [9:0]  encoder_status_latched;
    logic        error_flag_latched;
    logic        warning_flag_latched;
    logic        send_pending;
    logic        data_valid_d;

    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            encoder_position_latched <= '0;
            encoder_status_latched   <= '0;
            error_flag_latched       <= 1'b0;
            warning_flag_latched     <= 1'b0;
            send_pending             <= 1'b0;
            data_valid_d             <= 1'b0;
        end else begin
            data_valid_d <= data_valid;

            // rising edge detect on data_valid
            if (data_valid && !data_valid_d) begin
                encoder_position_latched <= encoder_position;
                encoder_status_latched   <= encoder_status;
                error_flag_latched       <= error_flag;
                warning_flag_latched     <= warning_flag;
                send_pending             <= 1'b1;
            end
        end
    end

    logic [7:0]  uart_data_in;
    logic        uart_data_valid;
    logic        uart_busy;

    logic [55:0] uart_packet;
    logic [55:0] uart_shift_reg;
    logic [1:0]  uart_byte_count;
    logic        packet_waiting;
    logic        uart_fire;

    // Format: 0x66 [POS_H] [POS_L] [STATUS_H] [STATUS_L] [FLAGS] 0x0D 0x0A
    assign uart_packet = {
        8'h0A, 8'h0D,  // Carriage return + line feed
        {error_flag, warning_flag, 6'b0},
        encoder_status_latched[7:0],
        encoder_position_latched[15:8],
        encoder_position_latched[7:0],
        8'h66  // Header
    };

    uart_transmit
    #(
        .INPUT_CLOCK_FREQ(100_000_000),
        .BAUD_RATE(115200)
    ) my_uart_transmit (
        .clk(clk_100mhz),
        .rst(rst),
        .din(uart_data_in),
        .trigger(uart_data_valid),
        .busy(uart_busy),
        .dout(uart_txd)
    );

    assign uart_data_valid = packet_waiting && !uart_busy;
    assign uart_data_in    = uart_shift_reg[7:0];
    assign uart_fire       = uart_data_valid;

    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            uart_shift_reg  <= 56'd0;  
            uart_byte_count <= 3'd0;  
            packet_waiting  <= 1'b0;
            send_pending    <= 1'b0;
        end else begin
            if (send_pending && !packet_waiting) begin  // FIX: Use latched flag
                uart_shift_reg  <= uart_packet;
                uart_byte_count <= 3'd0;
                packet_waiting  <= 1'b1;
                send_pending    <= 1'b0;
            end else if (uart_fire) begin
                if (uart_byte_count == 3'd4) begin  // FIX: Count to 4 (5 bytes)
                    packet_waiting <= 1'b0;
                end else begin
                    uart_shift_reg  <= {8'd0, uart_shift_reg[55:8]};
                    uart_byte_count <= uart_byte_count + 1'b1;
                end
            end
        end
    end
    
    

endmodule




`default_nettype wire