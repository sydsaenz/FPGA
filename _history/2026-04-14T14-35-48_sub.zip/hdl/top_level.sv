`default_nettype none

module top_level(
    input wire clk_100mhz,          // 100 MHz clock from Urbana board
    input wire [15:0] sw,           // Switches
    input wire [3:0] btn,           // Buttons
    output logic [15:0] led,        // LEDs
    output logic [2:0] rgb0,        // RGB LED 0
    output logic [2:0] rgb1,        // RGB LED 1
    output logic [3:0] ss0_an,      // Seven segment anodes
    output logic [3:0] ss1_an,
    output logic [6:0] ss0_c,       // Seven segment cathodes
    output logic [6:0] ss1_c,
    
    // PMOD JA pins for SSI (differential pairs)
    // Use PMOD connector with differential capability
    output wire pmod_ja_p1,              // SSI Clock positive
    output wire pmod_ja_n1,              // SSI Clock negative
    input wire pmod_ja_p2,               // SSI Data positive
    input wire pmod_ja_n2                // SSI Data negative
);

    // ===== Reset and Trigger Logic =====
    logic rst;
    logic trigger;
    logic [23:0] auto_trigger_counter;
    logic auto_trigger;
    
    assign rst = btn[0];
    
    // Auto-trigger for continuous reading (adjustable rate)
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            auto_trigger_counter <= '0;
            auto_trigger <= 1'b0;
        end else begin
            // Trigger every 100ms (well above tB = 70µs requirement)
            if (auto_trigger_counter >= 24'd10_000_000) begin
                auto_trigger_counter <= '0;
                auto_trigger <= 1'b1;
            end else begin
                auto_trigger_counter <= auto_trigger_counter + 1;
                auto_trigger <= 1'b0;
            end
        end
    end
    
    // Manual trigger with debouncing
    logic [19:0] btn_debounce;
    logic btn_trigger;
    
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            btn_debounce <= '0;
            btn_trigger <= 1'b0;
        end else begin
            if (btn[1]) begin
                if (btn_debounce < 20'd100_000) begin
                    btn_debounce <= btn_debounce + 1;
                    btn_trigger <= 1'b0;
                end else begin
                    btn_trigger <= 1'b1;
                end
            end else begin
                btn_debounce <= '0;
                btn_trigger <= 1'b0;
            end
        end
    end
    
    // Select trigger source: SW[15] = 1 for auto, 0 for manual
    assign trigger = sw[15] ? auto_trigger : btn_trigger;
    
    // ===== SSI Master Instance =====
    logic [18:0] encoder_position;
    logic [9:0] encoder_status;
    logic data_valid;
    logic busy;
    logic error_flag, warning_flag;
    
    // Adjust clock frequency based on cable length
    // SW[14:12] selects frequency:
    // 000 = 500 kHz (short cable <5m)
    // 001 = 250 kHz (medium cable 5-20m)
    // 010 = 125 kHz (long cable 20-50m)
    // 011 = 100 kHz (very long cable)
    
    logic [9:0] ssi_clk_freq;
    always_comb begin
        case (sw[14:12])
            3'b000:  ssi_clk_freq = 10'd500;
            3'b001:  ssi_clk_freq = 10'd250;
            3'b010:  ssi_clk_freq = 10'd125;
            3'b011:  ssi_clk_freq = 10'd100;
            default: ssi_clk_freq = 10'd250;
        endcase
    end
    
    ssi_master_differential #(
        .CLK_FREQ_MHZ(100),
        .POSITION_BITS(19),
        .STATUS_BITS(10),
        .TOTAL_BITS(30)
    ) ssi_inst (
        .clk(clk_100mhz),
        .rst(rst),
        .trigger(trigger),
        .ssi_clk_freq_khz(ssi_clk_freq),
        
        // Differential I/O (connected through OBUFDS/IBUFDS)
        .ssi_clk_p(pmod_ja_p1),
        .ssi_clk_n(pmod_ja_n1),
        .ssi_data_p(pmod_ja_p2),
        .ssi_data_n(pmod_ja_n2),
        
        // Parallel outputs
        .position(encoder_position),
        .status(encoder_status),
        .data_valid(data_valid),
        .busy(busy),
        .error_flag(error_flag),
        .warning_flag(warning_flag)
    );
    
    // ===== LED Display =====
    assign led[15] = sw[15];            // Auto-trigger mode indicator
    assign led[14] = busy;              // Busy indicator
    assign led[13] = error_flag;        // Error flag
    assign led[12] = warning_flag;      // Warning flag
    assign led[11] = data_valid;        // Data valid pulse
    assign led[10:0] = encoder_position[18:8];  // Upper 11 bits of position
    
    // ===== RGB LED Status =====
    // RGB0: Error/Warning/OK status
    assign rgb0[0] = error_flag;                        // Red = Error
    assign rgb0[1] = warning_flag && !error_flag;       // Green = Warning
    assign rgb0[2] = !error_flag && !warning_flag;      // Blue = OK
    
    // RGB1: Busy/Activity indicator (blink on data valid)
    logic [23:0] blink_counter;
    logic blink;
    
    always_ff @(posedge clk_100mhz) begin
        if (rst) begin
            blink_counter <= '0;
            blink <= 1'b0;
        end else begin
            if (data_valid) begin
                blink_counter <= 24'd5_000_000;  // 50ms blink
            end else if (blink_counter > 0) begin
                blink_counter <= blink_counter - 1;
            end
            
            blink <= (blink_counter > 0);
        end
    end
    
    assign rgb1[0] = 1'b0;
    assign rgb1[1] = blink;  // Green blink on new data
    assign rgb1[2] = 1'b0;
    
    // ===== Seven Segment Display =====
    // Display position value in hex
    logic [6:0] ss_c[7:0];
    logic [3:0] ss_digit[7:0];
    logic [31:0] display_value;
    
    // Multiplex display value based on SW[11:10]
    always_comb begin
        case (sw[11:10])
            2'b00: display_value = {13'b0, encoder_position};        // Position
            2'b01: display_value = {22'b0, encoder_status};          // Status
            2'b10: display_value = {encoder_position, 13'b0};        // Position shifted
            2'b11: display_value = 32'hDEADBEEF;                     // Test pattern
        endcase
    end
    
    // Extract hex digits
    assign ss_digit[7] = display_value[31:28];
    assign ss_digit[6] = display_value[27:24];
    assign ss_digit[5] = display_value[23:20];
    assign ss_digit[4] = display_value[19:16];
    assign ss_digit[3] = display_value[15:12];
    assign ss_digit[2] = display_value[11:8];
    assign ss_digit[1] = display_value[7:4];
    assign ss_digit[0] = display_value[3:0];
    
    // Hex to 7-segment decoders
    genvar i;
    generate
        for (i = 0; i < 8; i++) begin : seg_gen
            hex_to_7seg seg_decoder (
                .hex(ss_digit[i]),
                .segments(ss_c[i])
            );
        end
    endgenerate
    
    // Multiplex seven segment displays (simple: show 2 digits)
    assign ss0_an = 4'b1110;  // Enable rightmost digit
    assign ss1_an = 4'b1110;
    assign ss0_c = ~ss_c[5];  // Upper nibble
    assign ss1_c = ~ss_c[1];  // Lower nibble

endmodule


// ===== Hex to 7-Segment Decoder =====
module hex_to_7seg(
    input wire [3:0] hex,
    output logic [6:0] segments
);
    always_comb begin
        case (hex)
            4'h0: segments = 7'b0111111;
            4'h1: segments = 7'b0000110;
            4'h2: segments = 7'b1011011;
            4'h3: segments = 7'b1001111;
            4'h4: segments = 7'b1100110;
            4'h5: segments = 7'b1101101;
            4'h6: segments = 7'b1111101;
            4'h7: segments = 7'b0000111;
            4'h8: segments = 7'b1111111;
            4'h9: segments = 7'b1101111;
            4'hA: segments = 7'b1110111;
            4'hB: segments = 7'b1111100;
            4'hC: segments = 7'b0111001;
            4'hD: segments = 7'b1011110;
            4'hE: segments = 7'b1111001;
            4'hF: segments = 7'b1110001;
            default: segments = 7'b0000000;
        endcase
    end
endmodule

`default_nettype wire